cat << 'EOF' > setup.py
from setuptools import find_packages, setup

package_name = 'smart_pick_and_place'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kkm',
    maintainer_email='kkm@todo.todo',
    description='Smart Pick and Place Vision Package',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'run_vision = smart_pick_and_place.internalcamera:main',
        ],
    },
)
EOF
