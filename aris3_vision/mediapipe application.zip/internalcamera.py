import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import cv2
import numpy as np

# 최신 MediaPipe Tasks API 임포트
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

class MultiColorAndHandNode(Node):
    def __init__(self):
        super().__init__('multi_color_and_hand_node')
        
        # 1. 색상별 6가지 객체 퍼블리셔 선언
        self.publishers_dict = {
            "Red": self.create_publisher(Point, '/object_red_pixel', 10),
            "Green": self.create_publisher(Point, '/object_green_pixel', 10),
            "Blue": self.create_publisher(Point, '/object_blue_pixel', 10),
            # "Yellow": self.create_publisher(Point, '/object_yellow_pixel', 10),
           # "Gray": self.create_publisher(Point, '/object_gray_pixel', 10),
           # "White": self.create_publisher(Point, '/object_white_pixel', 10) 
 }
        # 손 랜드마크 퍼블리셔 선언
        self.hand_pub = self.create_publisher(Point, '/webcam_hand_pixel', 10)
        
        # 2. 웹캠 오픈 (내장 웹캠 0번)
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.get_logger().error("웹캠을 열 수 없습니다!")
        else:
            self.get_logger().info("웹캠 스트리밍 시작 성공!")

        # 3. MediaPipe HandLandmarker 초기화
        try:
            base_options = python.BaseOptions(model_asset_path='hand_landmarker.task')
            options = vision.HandLandmarkerOptions(
                base_options=base_options,
                running_mode=vision.RunningMode.IMAGE,
                num_hands=1
            )
            self.detector = vision.HandLandmarker.create_from_options(options)
            self.get_logger().info("MediaPipe HandLandmarker 모델 로드 성공!")
        except Exception as e:
            self.get_logger().error(f"MediaPipe 모델 로드 실패: {e}")

        # 손 관절 뼈대 구조 정의
        self.hand_connections = [
            (0, 1), (1, 2), (2, 3), (3, 4), # 엄지
            (0, 5), (5, 6), (6, 7), (7, 8), # 검지
            (5, 9), (9, 10), (10, 11), (11, 12), # 중지
            (9, 13), (13, 14), (14, 15), (15, 16), # 약지
            (13, 17), (17, 18), (18, 19), (19, 20), # 소지
            (0, 17) # 손바닥 기준선
        ]

        # 타이머 생성 (약 30fps)
        self.timer = self.create_timer(0.03, self.timer_callback)

    def timer_callback(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        height, width, _ = frame.shape
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # 4. 6가지 색상 정의 (HSV 범위 및 화면 표시용 BGR 색상)
        # ※ 주변 조명 환경에 따라 값이 미세하게 다를 수 있습니다.
        color_ranges = {
            "Red": {
                "lower": np.array([0, 120, 70]), "upper": np.array([10, 255, 255]), "bgr": (0, 0, 255)
            },
            "Green": {
                "lower": np.array([35, 80, 50]), "upper": np.array([85, 255, 255]), "bgr": (0, 255, 0)
            },
            "Blue": {
                "lower": np.array([100, 100, 50]), "upper": np.array([140, 255, 255]), "bgr": (255, 0, 0)
            }#,
           # "Yellow": {
               # "lower": np.array([20, 100, 100]), "upper": np.array([35, 255, 255]), "bgr": (0, 255, 255)
           # },
           # "Gray": {
               # "lower": np.array([0, 0, 50]), "upper": np.array([180, 30, 200]), "bgr": (128, 128, 128)
           # },
           # "White": {
               # "lower": np.array([0, 0, 200]), "upper": np.array([180, 30, 255]), "bgr": (255, 255, 255)
           # }
        }

        # 각 색상별로 검출 및 퍼블리시 수행
        for color_name, info in color_ranges.items():
            self.detect_color_object(
                frame, hsv, 
                info["lower"], info["upper"], 
                color_name, info["bgr"], 
                self.publishers_dict[color_name]
            )

        # 5. MediaPipe 손 21개 관절 추적 및 시각화
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        detection_result = self.detector.detect(mp_image)

        if detection_result.hand_landmarks:
            for hand_landmarks in detection_result.hand_landmarks:
                landmark_pixels = []
                for lm in hand_landmarks:
                    px = int(lm.x * width)
                    py = int(lm.y * height)
                    landmark_pixels.append((px, py))

                # 관절 점 찍기
                for pt in landmark_pixels:
                    cv2.circle(frame, pt, 4, (0, 0, 255), -1)

                # 뼈대 선 그리기
                for connection in self.hand_connections:
                    pt1 = landmark_pixels[connection[0]]
                    pt2 = landmark_pixels[connection[1]]
                    cv2.line(frame, pt1, pt2, (0, 255, 0), 2)

                # 검지 끝(8번) 좌표 퍼블리시
                index_tip = landmark_pixels[8]
                cx, cy = index_tip[0], index_tip[1]
                
                msg = Point()
                msg.x = float(cx)
                msg.y = float(cy)
                msg.z = 0.0
                self.hand_pub.publish(msg)

                cv2.circle(frame, (cx, cy), 8, (255, 0, 0), -1)
                cv2.putText(frame, f"Hand X:{cx} Y:{cy}", (cx - 30, cy - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)

        # 결과 화면 출력
        cv2.imshow('Multi-Color Objects & Hand Tracking', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            rclpy.shutdown()

    def detect_color_object(self, frame, hsv, lower_bound, upper_bound, color_name, bgr_color, publisher):
        mask = cv2.inRange(hsv, lower_bound, upper_bound)
        
        # 노이즈 제거를 위한 모폴로지 연산
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 500: # 너무 작은 노이즈 무시
                x, y, w, h = cv2.boundingRect(cnt)
                cx, cy = x + w // 2, y + h // 2  

                # ROS 2 픽셀 좌표 퍼블리시
                msg = Point()
                msg.x = float(cx)
                msg.y = float(cy)
                msg.z = 0.0
                publisher.publish(msg)

                # 화면 시각화 (바운딩 박스 및 텍스트)
                cv2.rectangle(frame, (x, y), (x + w, y + h), bgr_color, 2)
                cv2.circle(frame, (cx, cy), 5, bgr_color, -1)
                text = f"{color_name} ({cx},{cy})"
                cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.45, bgr_color, 2)

    def destroy_node(self):
        if self.cap.isOpened():
            self.cap.release()
        cv2.destroyAllWindows()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = MultiColorAndHandNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()

