import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import cv2
import numpy as np
import pyrealsense2 as rs

class ObjectDetectorPublisher(Node):
    def __init__(self):
        super().__init__('object_detector_publisher')
        
        self.red_pub = self.create_publisher(Point, '/object_red_coord', 10)
        self.green_pub = self.create_publisher(Point, '/object_green_coord', 10)
        self.blue_pub = self.create_publisher(Point, '/object_blue_coord', 10)
        
        self.pipeline = rs.pipeline()
        self.config = rs.config()
        self.config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
        self.config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
        
        try:
            profile = self.pipeline.start(self.config)
            self.depth_intrinsics = profile.get_stream(rs.stream.depth).as_video_stream_profile().get_intrinsics()
            self.align = rs.align(rs.stream.color)
            self.get_logger().info("RealSense 카메라 스트리밍 및 Depth 정렬 시작 성공!")
        except Exception as e:
            self.get_logger().error(f"카메라 시작 실패: {e}")

        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        try:
            frames = self.pipeline.wait_for_frames(timeout_ms=1000)
            aligned_frames = self.align.process(frames)
            color_frame = aligned_frames.get_color_frame()
            depth_frame = aligned_frames.get_depth_frame()
            
            if not color_frame or not depth_frame:
                return

            frame = np.asanyarray(color_frame.get_data())
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

            self.detect_and_publish(frame, hsv, depth_frame, 
                                    np.array([0, 100, 100]), np.array([10, 255, 255]), 
                                    "Red", (0, 0, 255), self.red_pub)
            self.detect_and_publish(frame, hsv, depth_frame, 
                                    np.array([35, 100, 100]), np.array([85, 255, 255]), 
                                    "Green", (0, 255, 0), self.green_pub)
            self.detect_and_publish(frame, hsv, depth_frame, 
                                    np.array([100, 100, 100]), np.array([130, 255, 255]), 
                                    "Blue", (255, 0, 0), self.blue_pub)

            cv2.imshow('Smart Pick and Place - Vision', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                rclpy.shutdown()

        except Exception as ex:
            pass

    def detect_and_publish(self, frame, hsv, depth_frame, lower_bound, upper_bound, color_name, bgr_color, publisher):
        mask = cv2.inRange(hsv, lower_bound, upper_bound)
        
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 500:  
                x, y, w, h = cv2.boundingRect(cnt)
                cx, cy = x + w // 2, y + h // 2  

                # [개선 1] 주변 픽셀 값을 모은 뒤 중앙값(Median)을 사용하여 튀는 노이즈 원천 차단
                depth_vals = []
                for dx in range(-3, 4):
                    for dy in range(-3, 4):
                        nx, ny = cx + dx, cy + dy
                        if 0 <= nx < 640 and 0 <= ny < 480:
                            d = depth_frame.get_distance(nx, ny)
                            if 0.1 < d < 3.0: # 유효 거리 범위(10cm ~ 3m) 내의 값만 수집
                                depth_vals.append(d)
                
                if not depth_vals:
                    continue # 유효한 깊이 값이 없으면 이번 루프 스킵 (0.000m 폭주 방지)

                depth_val = np.median(depth_vals) # 노이즈에 강한 중앙값 사용

                point_3d = rs.rs2_deproject_pixel_to_point(self.depth_intrinsics, [cx, cy], depth_val)
                pos_x = round(point_3d[0], 3)
                pos_y = round(point_3d[1], 3)
                pos_z = round(point_3d[2], 3)

                # [개선 2] 비정상적인 좌표 범위 튐 현상 방지 필터 (로봇 작업 반경 내만 허용)
                if abs(pos_x) > 1.5 or abs(pos_y) > 1.5 or pos_z > 2.0:
                    continue

                # ROS 2 퍼블리시
                msg = Point()
                msg.x = pos_x
                msg.y = pos_y
                msg.z = pos_z
                publisher.publish(msg)

                # 화면 및 로그 출력
                cv2.rectangle(frame, (x, y), (x + w, y + h), bgr_color, 2)
                cv2.circle(frame, (cx, cy), 5, bgr_color, -1)
                text = f"{color_name} X:{pos_x:.3f}m Y:{pos_y:.3f}m Z:{pos_z:.3f}m"
                cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.45, bgr_color, 2)
                
                self.get_logger().info(f"Published [{color_name}] -> X: {pos_x:.3f}m, Y: {pos_y:.3f}m, Z: {pos_z:.3f}m")

    def destroy_node(self):
        try:
            self.pipeline.stop()
        except:
            pass
        cv2.destroyAllWindows()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = ObjectDetectorPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()

