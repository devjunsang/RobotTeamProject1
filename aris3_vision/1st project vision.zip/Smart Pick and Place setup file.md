# 🤖 Smart Pick-and-Place: RealSense 3D Vision Node

Intel RealSense D455 카메라인 컬러(RGB)와 깊이(Depth) 스트림을 동기화하여, Red, Green, Blue 객체의 3D 공간 좌표(X, Y, Z 미터 단위)를 ROS 2 토픽으로 실시간 퍼블리시하는 비전 노드입니다.

## ⚙️ 시스템 요구사항 (Prerequisites)
- **OS**: Ubuntu 24.04 LTS
- **Middleware**: ROS 2 Jazzy
- **Hardware**: Intel RealSense D455 카메라 (Depth 센서 필수)
- **SDK**: Intel RealSense SDK 2.0 (`librealsense2`)

### 필수 파이썬 라이브러리
```bash
pip install opencv-python numpy pyrealsense2



압축 해제 및 실행 방법 (How to Build & Run)
1. 받아온 smart_pick_and_place.zip 파일의 압축을 풀어 ~/ros2_ws/src/ 폴더 아래에 놓습니다.

2.  워크스페이스 최상단(~/ros2_ws)에서 빌드합니다


명령어
cd ~/ros2_ws
colcon build --packages-select smart_pick_and_place
source install/setup.bash

비전 노드 실행 명령어(case 1)
ros2 run smart_pick_and_place detector_clean


*비전 노드 실행 명령어(case2)
python3 detector_clean.py
